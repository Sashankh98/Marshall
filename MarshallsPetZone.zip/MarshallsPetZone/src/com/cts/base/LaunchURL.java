package com.cts.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class LaunchURL {

	public static  WebDriver driver;
	@BeforeMethod
	public static void openBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "GoogleDriver/chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://www.marshallspetzone.com/");
			
		
	}
	@AfterMethod
	public static void CloseBrowser()
	{
		
		driver.close();
	}
}
