package com.cts.page;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.cts.base.ExcelWrite;

public class CatPage {

	private static By accessoriesLocation = By
			.xpath("//a[@class='_gray-darker search-link js-search-link'][contains(text(),'Accessories')]");
	
	private static By dropDownLocation= By.xpath(
			"//div[@class='products-sort-nb-dropdown products-sort-order dropdown']//i[@class='fa fa-angle-down']");
	
	private static By priceLocation=By.xpath("//a[contains(text(),'Price, low to high')]");
	
	private static By FirstElement = By.linkText("Pawzone Anti-Slip Spliced Flooring For Pets");
	
	private static By iconLocation = By.xpath("//i[@class='fa fa-th-list']");

	public static void clickOnAccessories(WebDriver driver) throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].click();", driver.findElement(accessoriesLocation));

		Thread.sleep(2000);

	}
	
	public static void clickOnDrop(WebDriver driver) throws InterruptedException
	{
		JavascriptExecutor js1 = (JavascriptExecutor) driver;

		js1.executeScript("arguments[0].click();", driver.findElement(dropDownLocation));
		Thread.sleep(5000);
		
	}
	public static void clickOnPrice(WebDriver driver)
	{
		
		Actions action = new Actions(driver);
		action.click(driver.findElement(priceLocation)).click().build().perform();

	}
	
	public static void getFirstElementData(WebDriver driver) throws InterruptedException, IOException
	{
		 String firstElement = driver.findElement(FirstElement).getText();
		 ExcelWrite.write(firstElement);
		 Thread.sleep(3000);
	}
	
	public static void clickOnIcon(WebDriver driver) throws InterruptedException
	{
		driver.findElement(iconLocation).click();
		Thread.sleep(2000);
		driver.navigate().refresh();
		
	}
	
	

}
