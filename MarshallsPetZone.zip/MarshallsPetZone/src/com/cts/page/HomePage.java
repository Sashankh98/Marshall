package com.cts.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

	private static By catLocation =By.linkText("Cat");
	
	public static void clickOnCat(WebDriver driver) throws InterruptedException
	{
		
		driver.findElement(catLocation).click();
		Thread.sleep(4000);
	}
}
