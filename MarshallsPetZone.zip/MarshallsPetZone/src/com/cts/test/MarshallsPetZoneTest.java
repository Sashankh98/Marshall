package com.cts.test;

import com.cts.base.LaunchURL;
import com.cts.base.ScreenShot;
import com.cts.page.CatPage;
import com.cts.page.HomePage;

public class MarshallsPetZoneTest extends LaunchURL {
	
	@org.testng.annotations.Test
	public static void Test() throws InterruptedException
	{
		
		HomePage.clickOnCat(driver);
		CatPage.clickOnAccessories(driver);
		CatPage.clickOnDrop(driver);
		CatPage.clickOnPrice(driver);
		ScreenShot.TakeScreenshot(driver);
		CatPage.clickOnIcon(driver);
		
	}

}
